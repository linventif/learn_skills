ENT.Type = "anim";
ENT.Base = "base_entity"
ENT.PrintName = "Learn Skills"
ENT.Author = "Linventif"
ENT.Category = "Linventif"
ENT.Spawnable = true
ENT.Contact = "https://dsc.gg/linventif"