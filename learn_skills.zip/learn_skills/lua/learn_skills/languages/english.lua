Learn_Skills.Language = {}

Learn_Skills.Language.No_Perm = "Permissions Insufisante"

// Chat Advertisement
Learn_Skills.Language.Ad_Reset = "Vous avez étais Role Play Kill, une nouvelle aventure commence pour vous."
Learn_Skills.Language.Ad_New_Adventure_P1 = "Votre aventure commence en temps que "
Learn_Skills.Language.Ad_New_Adventure_P2 = " plus d'info dans le /skills."

// Panel Confirm
Learn_Skills.Language.Panel_Cancel = "Cancel"
Learn_Skills.Language.Panel_Comfirm = "Comfirm"
Learn_Skills.Language.Panel_Confirm_Auto_RPK_M1 = "Are you sure you want to be Role Play Kill?"
Learn_Skills.Language.Panel_Confirm_Auto_RPK_M2 = "This results in the deletion of your current character."

// ULX Commands
Learn_Skills.Language.ULX_Reset_All = "Réinitialise Toutes les Données du Joueur."
Learn_Skills.Language.ULX_Reset_All_Log = "#A à réinitialise toutes les données de #T"

// Logs
Learn_Skills.Language.Logs_Categorie_Learn = "Learn"
Learn_Skills.Language.Logs_Categorie_Reroll = "Reroll"
Learn_Skills.Language.Logs_Categorie_Admin = "Admin"

Learn_Skills.Language.Logs_Learn = "{1} to teach {2} technique to {3} for {4}"
Learn_Skills.Language.Logs_Reroll = "{1} used a reroll and became a {2}"
Learn_Skills.Language.Logs_Reset = "{1} reset all data of {2}"
Learn_Skills.Language.Logs_Auto_RPK = "{1} it's self rpk and became a {2}"

Learn_Skills.Language.Logs_Nature_Set = "{1} set nature at {2} for {3}"

Learn_Skills.Language.Logs_Weapon_Reset = "{1} reset all weapons of {2}"
Learn_Skills.Language.Logs_Weapon_Give = "{1} give weapon {2} to {3}"
Learn_Skills.Language.Logs_Weapon_Remove = "{1} remove weapon {2} to {3}"

Learn_Skills.Language.Logs_Chakra_Reset = "{1} reset chakra of {2}"
Learn_Skills.Language.Logs_Chakra_Give = "{1} give {2} chakra to {3}"
Learn_Skills.Language.Logs_Chakra_Remove = "{1} remove {2} chakra to {3}"
Learn_Skills.Language.Logs_Chakra_Set = "{1} set chakra at {2} for {3}"

Learn_Skills.Language.Logs_Reroll_Reset = "{1} reset reroll of {2}"
Learn_Skills.Language.Logs_Reroll_Give = "{1} give {2} reroll to {3}"
Learn_Skills.Language.Logs_Reroll_Remove = "{1} remove {2} reroll to {3}"
Learn_Skills.Language.Logs_Reroll_Set = "{1} set reroll at {2} for {3}"